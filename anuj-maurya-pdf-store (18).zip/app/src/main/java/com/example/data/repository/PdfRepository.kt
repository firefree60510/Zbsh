package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.local.AppDatabase
import com.example.data.local.AppPreferences
import com.example.data.local.CustomPdfEntity
import com.example.data.local.SavedOrderEntity
import com.example.data.model.AdminStats
import com.example.data.model.AppSettings
import com.example.data.model.BannerItem
import com.example.data.model.OrderItem
import com.example.data.model.OrderResponseData
import com.example.data.model.PdfItem
import com.example.data.remote.FirestoreService
import com.example.data.sync.DataBackupManager
import com.example.data.sync.SharedSyncManager
import com.example.util.LinkHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PdfRepository(private val context: Context) {
    private val preferences = AppPreferences(context)
    private val db = AppDatabase.getDatabase(context)
    private val orderDao = db.savedOrderDao()
    private val pdfDao = db.customPdfDao()
    val firestore = FirestoreService(context)

    val savedOrders: Flow<List<OrderItem>> = orderDao.getAllOrders().map { list ->
        list.map { it.toOrderItem() }
    }

    suspend fun getSettings(): Result<AppSettings> = withContext(Dispatchers.IO) {
        // 1. Sync from Counterpart App (Admin <-> User)
        SharedSyncManager.pullDataFromCounterpart(context)

        // 2. Sync from Remote Firestore if available
        if (firestore.isAvailable()) {
            val cloudRes = firestore.getAppSettings()
            if (cloudRes.isSuccess) {
                val settings = cloudRes.getOrNull()!!
                preferences.announcement = settings.announcement
                preferences.upiId = settings.upiId
                preferences.upiName = settings.upiName
                preferences.upiQrUrl = settings.upiQrUrl
                preferences.whatsappSupport = settings.whatsappNumber
                preferences.youtubeUrl = LinkHelper.formatYouTubeUrl(settings.youtubeUrl)
                preferences.telegramUrl = LinkHelper.formatTelegramUrl(settings.telegramUrl)
                if (!settings.appLogoUrl.isNullOrEmpty()) {
                    preferences.appLogoUrl = settings.appLogoUrl
                }
                if (settings.banners.isNotEmpty()) {
                    preferences.homeBanners = settings.banners.map {
                        it.copy(youtubeUrl = LinkHelper.formatYouTubeUrl(it.youtubeUrl))
                    }
                }
                DataBackupManager.saveBackup(
                    context,
                    settings = settings,
                    banners = preferences.homeBanners
                )
                return@withContext Result.success(settings)
            }
        }

        // 3. Fallback to Local Persistent Data
        ensureInitialPdfs()
        val currentSettings = getLocalSettings()
        DataBackupManager.saveBackup(context, settings = currentSettings, banners = preferences.homeBanners)
        Result.success(currentSettings)
    }

    suspend fun getPdfs(
        boardClass: String? = null,
        category: String? = null,
        searchQuery: String? = null
    ): Result<List<PdfItem>> = withContext(Dispatchers.IO) {
        // Sync from Counterpart App
        SharedSyncManager.pullDataFromCounterpart(context)

        if (firestore.isAvailable()) {
            val cloudRes = firestore.getPosts()
            if (cloudRes.isSuccess) {
                val cloudPdfs = cloudRes.getOrNull() ?: emptyList()
                if (cloudPdfs.isNotEmpty()) {
                    cloudPdfs.forEach { pdf ->
                        pdfDao.insertPdf(CustomPdfEntity.fromPdfItem(pdf))
                    }
                    var list = cloudPdfs
                    if (!boardClass.isNullOrEmpty() && boardClass != "All") {
                        list = list.filter { it.boardClass.equals(boardClass, ignoreCase = true) }
                    }
                    if (!category.isNullOrEmpty() && category != "All") {
                        list = list.filter { it.category.equals(category, ignoreCase = true) }
                    }
                    if (!searchQuery.isNullOrBlank()) {
                        list = list.filter {
                            it.title.contains(searchQuery, ignoreCase = true) ||
                                    it.subject.contains(searchQuery, ignoreCase = true) ||
                                    it.category.contains(searchQuery, ignoreCase = true)
                        }
                    }
                    val all = pdfDao.getAllPdfs().map { it.toPdfItem() }
                    DataBackupManager.saveBackup(context, pdfs = all)
                    return@withContext Result.success(list)
                }
            }
        }

        ensureInitialPdfs()
        Result.success(getLocalFilteredPdfs(boardClass, category, searchQuery))
    }

    private suspend fun ensureInitialPdfs() {
        // Restore from disk backup if available to prevent data loss on update
        val backup = DataBackupManager.readBackup(context)
        if (backup?.appSettings != null) {
            val s = backup.appSettings
            if (s.upiId.isNotBlank()) preferences.upiId = s.upiId
            if (s.upiName.isNotBlank()) preferences.upiName = s.upiName
            if (!s.upiQrUrl.isNullOrBlank()) preferences.upiQrUrl = s.upiQrUrl
            if (s.announcement.isNotBlank()) preferences.announcement = s.announcement
            if (s.whatsappNumber.isNotBlank()) preferences.whatsappSupport = s.whatsappNumber
            if (s.youtubeUrl.isNotBlank()) preferences.youtubeUrl = LinkHelper.formatYouTubeUrl(s.youtubeUrl)
            if (s.telegramUrl.isNotBlank()) preferences.telegramUrl = LinkHelper.formatTelegramUrl(s.telegramUrl)
            if (!s.appLogoUrl.isNullOrBlank()) preferences.appLogoUrl = s.appLogoUrl
        }
        if (!backup?.banners.isNullOrEmpty()) {
            preferences.homeBanners = backup.banners!!.map {
                it.copy(youtubeUrl = LinkHelper.formatYouTubeUrl(it.youtubeUrl))
            }
        }

        val existing = pdfDao.getAllPdfs()
        if (existing.isEmpty()) {
            if (!backup?.pdfs.isNullOrEmpty()) {
                backup.pdfs!!.forEach { pdf ->
                    pdfDao.insertPdf(CustomPdfEntity.fromPdfItem(pdf))
                }
            } else {
                CuratedPdfData.allPdfs.forEach { pdf ->
                    pdfDao.insertPdf(CustomPdfEntity.fromPdfItem(pdf))
                }
            }
        }

        val currentPdfs = pdfDao.getAllPdfs().map { it.toPdfItem() }
        DataBackupManager.saveBackup(
            context,
            settings = getLocalSettings(),
            banners = preferences.homeBanners,
            pdfs = currentPdfs
        )
    }

    private suspend fun getLocalFilteredPdfs(boardClass: String?, category: String?, query: String?): List<PdfItem> {
        val entities = pdfDao.getAllPdfs()
        var list = entities.map { it.toPdfItem() }
        if (!boardClass.isNullOrEmpty() && boardClass != "All") {
            list = list.filter { it.boardClass.equals(boardClass, ignoreCase = true) }
        }
        if (!category.isNullOrEmpty() && category != "All") {
            list = list.filter { it.category.equals(category, ignoreCase = true) }
        }
        if (!query.isNullOrBlank()) {
            list = list.filter {
                it.title.contains(query, ignoreCase = true) ||
                        it.subject.contains(query, ignoreCase = true) ||
                        it.category.contains(query, ignoreCase = true)
            }
        }
        return list
    }

    suspend fun getPdfDetails(id: Long): Result<PdfItem> = withContext(Dispatchers.IO) {
        val local = pdfDao.getPdfById(id)?.toPdfItem()
            ?: CuratedPdfData.allPdfs.find { it.id == id }
            ?: CuratedPdfData.allPdfs.first()
        Result.success(local)
    }

    suspend fun addPdf(pdf: PdfItem): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val entity = CustomPdfEntity.fromPdfItem(pdf).copy(id = 0)
            val newId = pdfDao.insertPdf(entity)
            val itemWithId = pdf.copy(id = newId)

            val all = pdfDao.getAllPdfs().map { it.toPdfItem() }
            DataBackupManager.saveBackup(context, pdfs = all)

            // Broadcast to User App
            SharedSyncManager.broadcastPdfUpsert(context, itemWithId)

            if (firestore.isAvailable()) {
                firestore.addPost(itemWithId)
            }
            Result.success(newId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePdf(id: Long): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val rows = pdfDao.deletePdfById(id)
            val all = pdfDao.getAllPdfs().map { it.toPdfItem() }
            DataBackupManager.saveBackup(context, pdfs = all)

            // Broadcast to User App
            SharedSyncManager.broadcastPdfDelete(context, id)

            if (firestore.isAvailable()) {
                firestore.deletePost(id)
            }
            Result.success(rows > 0)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteAllPdfs(): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val rows = pdfDao.deleteAll()
            DataBackupManager.saveBackup(context, pdfs = emptyList())

            if (firestore.isAvailable()) {
                firestore.deleteAllPosts()
            }
            Result.success(rows > 0)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitOrder(
        screenshotUri: Uri,
        pdfId: Long,
        studentName: String,
        whatsappNumber: String,
        utrNumber: String?
    ): Result<OrderResponseData> = withContext(Dispatchers.IO) {
        preferences.studentName = studentName
        preferences.whatsappNumber = whatsappNumber

        val pdf = pdfDao.getPdfById(pdfId)?.toPdfItem() ?: CuratedPdfData.allPdfs.find { it.id == pdfId }
        val pdfTitle = pdf?.title ?: "UP Board PDF Material"
        val pdfPrice = pdf?.price ?: 29.0

        val cloudScreenshot = firestore.uriToBase64(screenshotUri) ?: saveScreenshotLocally(screenshotUri)

        val localOrderId = "ORD-${System.currentTimeMillis().toString().takeLast(6)}"
        val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val orderItem = OrderItem(
            orderId = localOrderId,
            pdfId = pdfId,
            pdfTitle = pdfTitle,
            pdfPrice = pdfPrice,
            studentName = studentName,
            whatsappNumber = whatsappNumber,
            utrNumber = utrNumber,
            screenshotUrl = cloudScreenshot,
            status = "Pending",
            statusMessage = "Verification pending. Admin will verify and activate your PDF within 1-2 hours.",
            createdAt = dateStr
        )

        orderDao.insertOrder(SavedOrderEntity.fromOrderItem(orderItem))
        preferences.lastOrderId = localOrderId

        val allOrders = orderDao.getAllOrdersSync().map { it.toOrderItem() }
        DataBackupManager.saveBackup(context, orders = allOrders)

        // Broadcast to Admin App
        SharedSyncManager.broadcastNewOrder(context, orderItem)

        if (firestore.isAvailable()) {
            try {
                firestore.submitOrder(
                    pdfId = pdfId,
                    pdfTitle = pdfTitle,
                    pdfPrice = pdfPrice,
                    studentName = studentName,
                    whatsappNumber = whatsappNumber,
                    utrNumber = utrNumber,
                    screenshotBase64OrUrl = cloudScreenshot
                )
            } catch (_: Exception) {}
        }

        Result.success(
            OrderResponseData(
                orderId = localOrderId,
                status = "Pending",
                message = "Payment screenshot received! Admin will verify your order shortly.",
                pdfTitle = pdfTitle,
                price = pdfPrice
            )
        )
    }

    fun adminLogin(username: String, pin: String): Result<Boolean> {
        val isValid = (username.equals("admin", ignoreCase = true) || username.equals("anuj", ignoreCase = true) || username.equals("anujmaurya", ignoreCase = true)) &&
                (pin == "admin123" || pin == "anuj123" || pin == "123456" || pin == "2026")
        return if (isValid) {
            preferences.isAdminLoggedIn = true
            Result.success(true)
        } else {
            Result.failure(Exception("Invalid Admin Credentials. Default PIN: admin123"))
        }
    }

    private fun saveScreenshotLocally(uri: Uri): String {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return uri.toString()
            val fileName = "order_screenshot_${System.currentTimeMillis()}.jpg"
            val file = File(context.filesDir, fileName)
            FileOutputStream(file).use { output ->
                inputStream.copyTo(output)
            }
            Uri.fromFile(file).toString()
        } catch (_: Exception) {
            uri.toString()
        }
    }

    suspend fun checkOrderStatus(orderId: String, whatsappNumber: String? = null): Result<OrderItem> = withContext(Dispatchers.IO) {
        SharedSyncManager.pullDataFromCounterpart(context)

        val local = orderDao.getOrderById(orderId)
        if (local != null) {
            return@withContext Result.success(local.toOrderItem())
        }

        val backup = DataBackupManager.readBackup(context)
        val backupOrder = backup?.orders?.find { it.orderId.equals(orderId, ignoreCase = true) }
        if (backupOrder != null) {
            orderDao.insertOrder(SavedOrderEntity.fromOrderItem(backupOrder))
            return@withContext Result.success(backupOrder)
        }

        if (firestore.isAvailable()) {
            val cloudRes = firestore.checkOrderStatus(orderId, whatsappNumber ?: "")
            if (cloudRes.isSuccess) {
                val order = cloudRes.getOrNull()!!
                orderDao.insertOrder(SavedOrderEntity.fromOrderItem(order))
                return@withContext Result.success(order)
            }
        }

        Result.failure(Exception("Order ID '$orderId' not found. Please check and try again."))
    }

    suspend fun getOrderById(orderId: String): Result<OrderItem> = withContext(Dispatchers.IO) {
        val local = orderDao.getOrderById(orderId)
        if (local != null) {
            return@withContext Result.success(local.toOrderItem())
        }
        val backup = DataBackupManager.readBackup(context)
        val backupOrder = backup?.orders?.find { it.orderId == orderId }
        if (backupOrder != null) {
            orderDao.insertOrder(SavedOrderEntity.fromOrderItem(backupOrder))
            return@withContext Result.success(backupOrder)
        }
        Result.failure(Exception("Order not found with ID: $orderId"))
    }

    suspend fun getAdminOrders(statusFilter: String? = null): Result<Pair<AdminStats, List<OrderItem>>> = withContext(Dispatchers.IO) {
        // Sync orders from Counterpart App
        SharedSyncManager.pullDataFromCounterpart(context)

        var localOrders = orderDao.getAllOrdersSync().map { it.toOrderItem() }
        val totalRevenue = localOrders.filter { it.status.equals("Approved", ignoreCase = true) }
            .sumOf { it.pdfPrice }
        val pendingCount = localOrders.count { it.status.equals("Pending", ignoreCase = true) }
        val approvedCount = localOrders.count { it.status.equals("Approved", ignoreCase = true) }

        val stats = AdminStats(
            totalRevenue = totalRevenue,
            totalOrders = localOrders.size,
            pendingOrders = pendingCount,
            approvedOrders = approvedCount
        )

        if (!statusFilter.isNullOrBlank() && statusFilter != "All") {
            localOrders = localOrders.filter { it.status.equals(statusFilter, ignoreCase = true) }
        }

        Result.success(Pair(stats, localOrders))
    }

    suspend fun getAdminDashboardData(): Result<Pair<AdminStats, List<OrderItem>>> = getAdminOrders()

    suspend fun updateAdminOrderStatus(
        orderId: String,
        newStatus: String,
        message: String?,
        downloadUrl: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        orderDao.updateOrderStatus(orderId, newStatus, message, downloadUrl)

        val allOrders = orderDao.getAllOrdersSync().map { it.toOrderItem() }
        DataBackupManager.saveBackup(context, orders = allOrders)

        // Broadcast to User App
        SharedSyncManager.broadcastOrderStatus(context, orderId, newStatus, message, downloadUrl)

        if (firestore.isAvailable()) {
            firestore.updateOrderStatus(orderId, newStatus, message, downloadUrl)
        }
        Result.success(Unit)
    }

    suspend fun updateAdminSettings(
        upiId: String,
        upiName: String,
        announcement: String,
        whatsapp: String,
        youtubeUrl: String,
        telegramUrl: String,
        upiQrUrl: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanYt = LinkHelper.formatYouTubeUrl(youtubeUrl)
        val cleanTg = LinkHelper.formatTelegramUrl(telegramUrl)

        preferences.upiId = upiId
        preferences.upiName = upiName
        preferences.announcement = announcement
        preferences.whatsappSupport = whatsapp
        preferences.youtubeUrl = cleanYt
        preferences.telegramUrl = cleanTg
        if (upiQrUrl != null) {
            preferences.upiQrUrl = upiQrUrl
        }

        val settings = getLocalSettings()
        DataBackupManager.saveBackup(
            context,
            settings = settings,
            banners = preferences.homeBanners
        )

        // Broadcast to User App
        SharedSyncManager.broadcastSettings(context, settings)

        if (firestore.isAvailable()) {
            firestore.saveAppSettings(settings)
        }
        Result.success(Unit)
    }

    suspend fun updateAdminBanners(banners: List<BannerItem>): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanBanners = banners.map {
            it.copy(youtubeUrl = LinkHelper.formatYouTubeUrl(it.youtubeUrl))
        }
        preferences.homeBanners = cleanBanners
        val current = getLocalSettings().copy(banners = cleanBanners)
        DataBackupManager.saveBackup(context, settings = current, banners = cleanBanners)

        // Broadcast to User App
        SharedSyncManager.broadcastSettings(context, current)

        if (firestore.isAvailable()) {
            firestore.saveAppSettings(current)
        }
        Result.success(Unit)
    }

    fun saveQrUriToInternalStorage(uri: Uri): String {
        val cloudBase64 = firestore.uriToBase64(uri)
        if (cloudBase64 != null) {
            preferences.upiQrUrl = cloudBase64
            return cloudBase64
        }
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Cannot open QR image")
        val file = File(context.filesDir, "admin_upi_qr.jpg")
        FileOutputStream(file).use { output ->
            inputStream.copyTo(output)
        }
        val fileUri = Uri.fromFile(file).toString()
        preferences.upiQrUrl = fileUri
        return fileUri
    }

    fun saveCoverImageToInternalStorage(uri: Uri): String {
        val cloudBase64 = firestore.uriToBase64(uri)
        if (cloudBase64 != null) {
            return cloudBase64
        }
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Cannot open Cover image")
        val fileName = "pdf_cover_${System.currentTimeMillis()}.jpg"
        val file = File(context.filesDir, fileName)
        FileOutputStream(file).use { output ->
            inputStream.copyTo(output)
        }
        return Uri.fromFile(file).toString()
    }

    fun saveLogoUriToInternalStorage(uri: Uri): String {
        val cloudBase64 = firestore.uriToBase64(uri)
        if (cloudBase64 != null) {
            preferences.appLogoUrl = cloudBase64
            return cloudBase64
        }
        val inputStream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Cannot open Logo image")
        val file = File(context.filesDir, "app_custom_logo.jpg")
        FileOutputStream(file).use { output ->
            inputStream.copyTo(output)
        }
        val fileUri = Uri.fromFile(file).toString()
        preferences.appLogoUrl = fileUri
        return fileUri
    }

    suspend fun updateAdminLogo(logoUri: Uri?): Result<String?> = withContext(Dispatchers.IO) {
        if (logoUri != null) {
            val savedUrl = saveLogoUriToInternalStorage(logoUri)
            val current = getLocalSettings().copy(appLogoUrl = savedUrl)
            DataBackupManager.saveBackup(context, settings = current)
            SharedSyncManager.broadcastSettings(context, current)

            if (firestore.isAvailable()) {
                firestore.saveAppSettings(current)
            }
            Result.success(savedUrl)
        } else {
            Result.success(preferences.appLogoUrl)
        }
    }

    fun getLocalSettings(): AppSettings = AppSettings(
        appName = "Anuj Maurya",
        announcement = preferences.announcement,
        appLogoUrl = preferences.appLogoUrl,
        homeBannerUrl = preferences.homeBannerUrl,
        banners = preferences.homeBanners,
        upiId = preferences.upiId,
        upiName = preferences.upiName,
        upiQrUrl = preferences.upiQrUrl,
        whatsappNumber = preferences.whatsappSupport,
        youtubeUrl = LinkHelper.formatYouTubeUrl(preferences.youtubeUrl),
        telegramUrl = LinkHelper.formatTelegramUrl(preferences.telegramUrl),
        paymentInstructions = "1. Pay the exact PDF price using the UPI ID or QR Code.\n2. Take a screenshot of the successful payment screen.\n3. Upload screenshot with your WhatsApp number.\n4. Admin manually verifies payment and activates download."
    )
}
