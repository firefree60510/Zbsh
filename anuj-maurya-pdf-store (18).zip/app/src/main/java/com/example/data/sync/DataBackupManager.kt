package com.example.data.sync

import android.content.Context
import android.util.Log
import com.example.data.model.AppSettings
import com.example.data.model.BannerItem
import com.example.data.model.OrderItem
import com.example.data.model.PdfItem
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.io.File

object DataBackupManager {
    private const val TAG = "DataBackupManager"
    private const val BACKUP_FILENAME = "anuj_store_data_backup.json"

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    data class BackupPayload(
        val appSettings: AppSettings? = null,
        val banners: List<BannerItem>? = null,
        val pdfs: List<PdfItem>? = null,
        val orders: List<OrderItem>? = null,
        val updatedAt: Long = System.currentTimeMillis()
    )

    private val payloadAdapter = moshi.adapter(BackupPayload::class.java)

    private fun getBackupFiles(context: Context): List<File> {
        val files = mutableListOf<File>()
        try {
            files.add(File(context.filesDir, BACKUP_FILENAME))
        } catch (_: Exception) {}
        try {
            val extDir = context.getExternalFilesDir(null)
            if (extDir != null) {
                files.add(File(extDir, BACKUP_FILENAME))
            }
        } catch (_: Exception) {}
        return files
    }

    @Synchronized
    fun readBackup(context: Context): BackupPayload? {
        val files = getBackupFiles(context)
        for (file in files) {
            if (file.exists() && file.length() > 0) {
                try {
                    val json = file.readText()
                    val payload = payloadAdapter.fromJson(json)
                    if (payload != null) {
                        return payload
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error reading backup file ${file.absolutePath}: ${e.message}")
                }
            }
        }
        return null
    }

    @Synchronized
    fun saveBackup(
        context: Context,
        settings: AppSettings? = null,
        banners: List<BannerItem>? = null,
        pdfs: List<PdfItem>? = null,
        orders: List<OrderItem>? = null
    ) {
        val existing = readBackup(context)
        val merged = BackupPayload(
            appSettings = settings ?: existing?.appSettings,
            banners = banners ?: existing?.banners,
            pdfs = pdfs ?: existing?.pdfs,
            orders = orders ?: existing?.orders,
            updatedAt = System.currentTimeMillis()
        )

        try {
            val json = payloadAdapter.toJson(merged)
            val files = getBackupFiles(context)
            for (file in files) {
                try {
                    file.parentFile?.mkdirs()
                    file.writeText(json)
                } catch (e: Exception) {
                    Log.w(TAG, "Failed writing to ${file.absolutePath}: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to serialize backup: ${e.message}")
        }
    }
}
