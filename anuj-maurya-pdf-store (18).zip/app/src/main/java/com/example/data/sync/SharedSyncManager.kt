package com.example.data.sync

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.AppPreferences
import com.example.data.local.CustomPdfEntity
import com.example.data.local.SavedOrderEntity
import com.example.data.model.AppSettings
import com.example.data.model.BannerItem
import com.example.data.model.OrderItem
import com.example.data.model.PdfItem
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SharedSyncManager {
    private const val TAG = "SharedSyncManager"
    private const val USER_PKG = "com.aistudio.pdfstore.ajmy"
    private const val ADMIN_PKG = "com.aistudio.pdfstore.ajmy.admin"

    private val USER_URI = Uri.parse("content://$USER_PKG.provider")
    private val ADMIN_URI = Uri.parse("content://$ADMIN_PKG.provider")

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    private fun getCounterpartUri(context: Context): Uri {
        return if (context.packageName == ADMIN_PKG) USER_URI else ADMIN_URI
    }

    suspend fun broadcastSettings(context: Context, settings: AppSettings) = withContext(Dispatchers.IO) {
        try {
            val targetUri = getCounterpartUri(context)
            val bundle = Bundle()
            val adapter = moshi.adapter(AppSettings::class.java)
            bundle.putString("settings_json", adapter.toJson(settings))
            context.contentResolver.call(targetUri, "sync_settings", null, bundle)
            Log.d(TAG, "broadcastSettings sent to $targetUri")
        } catch (e: Exception) {
            Log.w(TAG, "broadcastSettings error: ${e.message}")
        }
    }

    suspend fun broadcastPdfUpsert(context: Context, pdf: PdfItem) = withContext(Dispatchers.IO) {
        try {
            val targetUri = getCounterpartUri(context)
            val bundle = Bundle()
            val adapter = moshi.adapter(PdfItem::class.java)
            bundle.putString("pdf_json", adapter.toJson(pdf))
            context.contentResolver.call(targetUri, "sync_pdf_upsert", null, bundle)
            Log.d(TAG, "broadcastPdfUpsert sent to $targetUri")
        } catch (e: Exception) {
            Log.w(TAG, "broadcastPdfUpsert error: ${e.message}")
        }
    }

    suspend fun broadcastPdfDelete(context: Context, pdfId: Long) = withContext(Dispatchers.IO) {
        try {
            val targetUri = getCounterpartUri(context)
            val bundle = Bundle().apply { putLong("pdf_id", pdfId) }
            context.contentResolver.call(targetUri, "sync_pdf_delete", null, bundle)
            Log.d(TAG, "broadcastPdfDelete sent to $targetUri")
        } catch (e: Exception) {
            Log.w(TAG, "broadcastPdfDelete error: ${e.message}")
        }
    }

    suspend fun broadcastNewOrder(context: Context, order: OrderItem) = withContext(Dispatchers.IO) {
        try {
            val targetUri = getCounterpartUri(context)
            val bundle = Bundle()
            val adapter = moshi.adapter(OrderItem::class.java)
            bundle.putString("order_json", adapter.toJson(order))
            context.contentResolver.call(targetUri, "sync_new_order", null, bundle)
            Log.d(TAG, "broadcastNewOrder sent to $targetUri")
        } catch (e: Exception) {
            Log.w(TAG, "broadcastNewOrder error: ${e.message}")
        }
    }

    suspend fun broadcastOrderStatus(
        context: Context,
        orderId: String,
        status: String,
        message: String? = null,
        downloadUrl: String? = null
    ) = withContext(Dispatchers.IO) {
        try {
            val targetUri = getCounterpartUri(context)
            val bundle = Bundle().apply {
                putString("order_id", orderId)
                putString("new_status", status)
                putString("message", message)
                putString("download_url", downloadUrl)
            }
            context.contentResolver.call(targetUri, "sync_order_status", null, bundle)
            Log.d(TAG, "broadcastOrderStatus sent to $targetUri")
        } catch (e: Exception) {
            Log.w(TAG, "broadcastOrderStatus error: ${e.message}")
        }
    }

    suspend fun pullDataFromCounterpart(context: Context) = withContext(Dispatchers.IO) {
        try {
            val targetUri = getCounterpartUri(context)
            val response = context.contentResolver.call(targetUri, "get_all_data", null, null) ?: return@withContext
            val db = AppDatabase.getDatabase(context)
            val prefs = AppPreferences(context)
            val pdfDao = db.customPdfDao()
            val orderDao = db.savedOrderDao()

            val settingsJson = response.getString("settings_json")
            if (!settingsJson.isNullOrBlank()) {
                try {
                    val sAdapter = moshi.adapter(AppSettings::class.java)
                    val s = sAdapter.fromJson(settingsJson)
                    if (s != null) {
                        prefs.announcement = s.announcement
                        prefs.upiId = s.upiId
                        prefs.upiName = s.upiName
                        prefs.upiQrUrl = s.upiQrUrl
                        prefs.whatsappSupport = s.whatsappNumber
                        prefs.youtubeUrl = s.youtubeUrl
                        prefs.telegramUrl = s.telegramUrl
                        if (!s.appLogoUrl.isNullOrEmpty()) prefs.appLogoUrl = s.appLogoUrl
                        if (s.banners.isNotEmpty()) prefs.homeBanners = s.banners
                        DataBackupManager.saveBackup(context, settings = s, banners = s.banners)
                    }
                } catch (_: Exception) {}
            }

            val pdfsJson = response.getString("pdfs_json")
            if (!pdfsJson.isNullOrBlank()) {
                try {
                    val pdfsType = Types.newParameterizedType(List::class.java, PdfItem::class.java)
                    val pAdapter = moshi.adapter<List<PdfItem>>(pdfsType)
                    val pdfList = pAdapter.fromJson(pdfsJson)
                    if (!pdfList.isNullOrEmpty()) {
                        pdfList.forEach { pdf ->
                            pdfDao.insertPdf(CustomPdfEntity.fromPdfItem(pdf))
                        }
                        val all = pdfDao.getAllPdfs().map { it.toPdfItem() }
                        DataBackupManager.saveBackup(context, pdfs = all)
                    }
                } catch (_: Exception) {}
            }

            val ordersJson = response.getString("orders_json")
            if (!ordersJson.isNullOrBlank()) {
                try {
                    val ordersType = Types.newParameterizedType(List::class.java, OrderItem::class.java)
                    val oAdapter = moshi.adapter<List<OrderItem>>(ordersType)
                    val orderList = oAdapter.fromJson(ordersJson)
                    if (!orderList.isNullOrEmpty()) {
                        orderList.forEach { order ->
                            orderDao.insertOrder(SavedOrderEntity.fromOrderItem(order))
                        }
                        val all = orderDao.getAllOrdersSync().map { it.toOrderItem() }
                        DataBackupManager.saveBackup(context, orders = all)
                    }
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            Log.d(TAG, "pullDataFromCounterpart: Counterpart not installed or not answering (${e.message})")
        }
    }
}
