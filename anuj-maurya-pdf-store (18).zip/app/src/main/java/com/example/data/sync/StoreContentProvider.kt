package com.example.data.sync

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import com.example.data.local.AppDatabase
import com.example.data.local.AppPreferences
import com.example.data.local.CustomPdfEntity
import com.example.data.local.SavedOrderEntity
import com.example.data.model.AppSettings
import com.example.data.model.BannerItem
import com.example.data.model.OrderItem
import com.example.data.model.PdfItem
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.runBlocking

class StoreContentProvider : ContentProvider() {

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    override fun onCreate(): Boolean = true

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle? {
        val ctx = context ?: return null
        val response = Bundle()
        val db = AppDatabase.getDatabase(ctx)
        val prefs = AppPreferences(ctx)
        val pdfDao = db.customPdfDao()
        val orderDao = db.savedOrderDao()

        when (method) {
            "get_all_data" -> {
                runBlocking {
                    val settings = AppSettings(
                        appName = "Anuj Maurya",
                        announcement = prefs.announcement,
                        appLogoUrl = prefs.appLogoUrl,
                        homeBannerUrl = prefs.homeBannerUrl,
                        banners = prefs.homeBanners,
                        upiId = prefs.upiId,
                        upiName = prefs.upiName,
                        upiQrUrl = prefs.upiQrUrl,
                        whatsappNumber = prefs.whatsappSupport,
                        youtubeUrl = prefs.youtubeUrl,
                        telegramUrl = prefs.telegramUrl
                    )
                    val settingsAdapter = moshi.adapter(AppSettings::class.java)
                    response.putString("settings_json", settingsAdapter.toJson(settings))

                    val bannersType = Types.newParameterizedType(List::class.java, BannerItem::class.java)
                    val bannersAdapter = moshi.adapter<List<BannerItem>>(bannersType)
                    response.putString("banners_json", bannersAdapter.toJson(prefs.homeBanners))

                    val pdfList = pdfDao.getAllPdfs().map { it.toPdfItem() }
                    val pdfsType = Types.newParameterizedType(List::class.java, PdfItem::class.java)
                    val pdfsAdapter = moshi.adapter<List<PdfItem>>(pdfsType)
                    response.putString("pdfs_json", pdfsAdapter.toJson(pdfList))

                    val orderList = orderDao.getAllOrdersSync().map { it.toOrderItem() }
                    val ordersType = Types.newParameterizedType(List::class.java, OrderItem::class.java)
                    val ordersAdapter = moshi.adapter<List<OrderItem>>(ordersType)
                    response.putString("orders_json", ordersAdapter.toJson(orderList))
                }
                return response
            }

            "sync_settings" -> {
                val settingsJson = extras?.getString("settings_json")
                if (!settingsJson.isNullOrBlank()) {
                    try {
                        val adapter = moshi.adapter(AppSettings::class.java)
                        val s = adapter.fromJson(settingsJson)
                        if (s != null) {
                            prefs.announcement = s.announcement
                            prefs.upiId = s.upiId
                            prefs.upiName = s.upiName
                            prefs.upiQrUrl = s.upiQrUrl
                            prefs.whatsappSupport = s.whatsappNumber
                            prefs.youtubeUrl = s.youtubeUrl
                            prefs.telegramUrl = s.telegramUrl
                            if (!s.appLogoUrl.isNullOrEmpty()) prefs.appLogoUrl = s.appLogoUrl
                            if (s.banners.isNotEmpty()) prefs.homeBanners = s.banners
                            DataBackupManager.saveBackup(ctx, settings = s, banners = s.banners)
                            response.putBoolean("success", true)
                        }
                    } catch (_: Exception) {}
                }
                return response
            }

            "sync_pdf_upsert" -> {
                val pdfJson = extras?.getString("pdf_json")
                if (!pdfJson.isNullOrBlank()) {
                    try {
                        val adapter = moshi.adapter(PdfItem::class.java)
                        val item = adapter.fromJson(pdfJson)
                        if (item != null) {
                            runBlocking {
                                pdfDao.insertPdf(CustomPdfEntity.fromPdfItem(item))
                                val all = pdfDao.getAllPdfs().map { it.toPdfItem() }
                                DataBackupManager.saveBackup(ctx, pdfs = all)
                            }
                            response.putBoolean("success", true)
                        }
                    } catch (_: Exception) {}
                }
                return response
            }

            "sync_pdf_delete" -> {
                val pdfId = extras?.getLong("pdf_id", -1L) ?: -1L
                if (pdfId != -1L) {
                    runBlocking {
                        pdfDao.deletePdfById(pdfId)
                        val all = pdfDao.getAllPdfs().map { it.toPdfItem() }
                        DataBackupManager.saveBackup(ctx, pdfs = all)
                    }
                    response.putBoolean("success", true)
                }
                return response
            }

            "sync_new_order" -> {
                val orderJson = extras?.getString("order_json")
                if (!orderJson.isNullOrBlank()) {
                    try {
                        val adapter = moshi.adapter(OrderItem::class.java)
                        val item = adapter.fromJson(orderJson)
                        if (item != null) {
                            runBlocking {
                                orderDao.insertOrder(SavedOrderEntity.fromOrderItem(item))
                                val all = orderDao.getAllOrdersSync().map { it.toOrderItem() }
                                DataBackupManager.saveBackup(ctx, orders = all)
                            }
                            response.putBoolean("success", true)
                        }
                    } catch (_: Exception) {}
                }
                return response
            }

            "sync_order_status" -> {
                val orderId = extras?.getString("order_id")
                val newStatus = extras?.getString("new_status")
                val message = extras?.getString("message")
                val downloadUrl = extras?.getString("download_url")
                if (!orderId.isNullOrBlank() && !newStatus.isNullOrBlank()) {
                    runBlocking {
                        orderDao.updateOrderStatus(orderId, newStatus, message, downloadUrl)
                        val all = orderDao.getAllOrdersSync().map { it.toOrderItem() }
                        DataBackupManager.saveBackup(ctx, orders = all)
                    }
                    response.putBoolean("success", true)
                }
                return response
            }
        }
        return response
    }

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? = null
    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
