package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF1E40AF)
val BlueSecondary = Color(0xFF2563EB)
val BlueDark = Color(0xFF1E3A8A)
val BlueLight = Color(0xFF60A5FA)

val AmberAccent = Color(0xFFF59E0B)
val AmberDark = Color(0xFFD97706)
val AmberLight = Color(0xFFFDE68A)

val GreenSuccess = Color(0xFF16A34A)
val RedError = Color(0xFFDC2626)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val BorderLight = Color(0xFFE2E8F0)

// Admin Bright Clean Theme Colors (No Dark/Black UI)
val AdminPrimary = Color(0xFF1E40AF)
val AdminHeaderBg = Color(0xFF1E3A8A)
val AdminCardBg = Color(0xFFFFFFFF)
val AdminBorder = Color(0xFFE2E8F0)
val AdminTextDark = Color(0xFF0F172A)
val AdminTextMuted = Color(0xFF64748B)
