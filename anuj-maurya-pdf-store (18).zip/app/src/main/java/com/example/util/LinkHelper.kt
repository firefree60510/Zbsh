package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object LinkHelper {

    fun formatYouTubeUrl(rawUrl: String?): String {
        if (rawUrl.isNullOrBlank()) return "https://youtube.com/@anujmauryapdf"
        val trimmed = rawUrl.trim()
        return when {
            trimmed.startsWith("@") -> "https://www.youtube.com/$trimmed"
            trimmed.startsWith("youtube.com") || trimmed.startsWith("youtu.be") || trimmed.startsWith("m.youtube.com") -> "https://$trimmed"
            !trimmed.startsWith("http://") && !trimmed.startsWith("https://") -> "https://$trimmed"
            else -> trimmed
        }
    }

    fun formatTelegramUrl(rawUrl: String?): String {
        if (rawUrl.isNullOrBlank()) return "https://t.me/anujmauryapdf"
        val trimmed = rawUrl.trim()
        return when {
            trimmed.startsWith("@") -> "https://t.me/${trimmed.removePrefix("@")}"
            trimmed.startsWith("t.me/") -> "https://$trimmed"
            !trimmed.startsWith("http://") && !trimmed.startsWith("https://") -> "https://$trimmed"
            else -> trimmed
        }
    }

    fun openYouTube(context: Context, rawUrl: String?) {
        val targetUrl = formatYouTubeUrl(rawUrl)
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
            } catch (e: Exception) {
                Toast.makeText(context, "YouTube link open नहीं हो सकी", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun openTelegram(context: Context, rawUrl: String?) {
        val targetUrl = formatTelegramUrl(rawUrl)
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
            } catch (e: Exception) {
                Toast.makeText(context, "Telegram link open नहीं हो सकी", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
